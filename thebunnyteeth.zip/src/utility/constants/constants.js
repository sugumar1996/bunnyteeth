export const routes = {
    HOME_BLOG: '/home-blog',
    SINGLE_POST: '/single-post',
    VIEW_ALL_POST: '/view-all-post',
    ROOT: '/',
    LOGIN: '/login',
    SIGNUP: '/signup',
    NOTFOUND: '/notfound',
    ABOUT: '/about',
    
}