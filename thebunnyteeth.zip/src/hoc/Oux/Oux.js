const Oux = (props) => {
  return props.children;
};
export default Oux;
