import React from "react";
import { baseImagePath } from "utility/utility";

export const Footer = () => {
  return (
    <div class="footer_sec margin_T120">
      <div class="container">
        {/*<footer class="footer_warp">
          <div class="row">
            <div class="col-lg-4">
              <div class="footer_list">
                <div class="footer_header">
                  <h5 class="footer_title">OUR LINKS</h5>
                </div>
                <ul class="nav flex-column custom_ul footer_ul">
                  <li class="nav-item custom_li footer_li"><a href="#" class="nav-link p-0">Admissions</a>
                  </li>
                  <li class="nav-item custom_li footer_li"><a href="#" class="nav-link p-0">FAQs</a></li>
                  <li class="nav-item custom_li footer_li"><a href="#" class="nav-link p-0">Contact Us</a>
                  </li>
                  <li class="nav-item custom_li footer_li"><a href="#" class="nav-link p-0">Credits</a>
                  </li>
                </ul>
              </div>
            </div>
            <div class="col-lg-4">
              <div class="footer_list">
                <div class="footer_header">
                  <h5 class="footer_title">OUR SCHOOL</h5>
                </div>
                <ul class="nav flex-column custom_ul footer_ul">
                  <li class="nav-item custom_li footer_li"><a href="#"
                    class="nav-link p-0">Pre-Kindergarten</a></li>
                  <li class="nav-item custom_li footer_li"><a href="#"
                    class="nav-link p-0">Kindergarten</a></li>
                  <li class="nav-item custom_li footer_li"><a href="#" class="nav-link p-0">Primary
                    school</a></li>
                  <li class="nav-item custom_li footer_li"><a href="#" class="nav-link p-0">Middle
                    school</a></li>
                </ul>
              </div>
            </div>
          </div>
          <div class="footer_right_content">
            <div class="fr_inner">
              <div class="footer_header">
                <h5 class="footer_title white_text">GET IN TOUCH</h5>
              </div>
              <ul class="nav custom_ul footer_ul">
                <li class="nav-item custom_li footer_li"><a href="#"
                  class="nav-link p-0 social_link color_red">
                  <img src={baseImagePath("icons/ellipse_1.png")} class="custom_img" alt="youTube" />
                </a></li>
                <li class="nav-item custom_li footer_li"><a href="#"
                  class="nav-link p-0 social_link color_blue">
                  <img src={baseImagePath("icons/ellipse_2.png")} class="custom_img" alt="youTube" />
                </a></li>
                <li class="nav-item custom_li footer_li"><a href="#"
                  class="nav-link p-0 social_link color_violet">
                  <img src={baseImagePath("icons/ellipse_3.png")} class="custom_img" alt="youTube" />
                </a></li>
              </ul>
            </div>
          </div>
  </footer>*/}
      </div>
    </div>
  );
};
